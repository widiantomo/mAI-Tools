# MelGAN-VC
MelGAN-VC: Voice Conversion and Audio Style Transfer on arbitrarily long samples using Spectrograms

Paper: https://arxiv.org/abs/1910.03713

Use the provided notebook to experiment yourself with MelGAN-VC.

Requirement: Tensorflow 2.0 or higher.

Have fun!
